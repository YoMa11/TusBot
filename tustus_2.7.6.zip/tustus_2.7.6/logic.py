from __future__ import annotations
import logging, re, time, sqlite3, asyncio
from typing import List, Tuple
import requests
from bs4 import BeautifulSoup as BS
from config import URL, USER_AGENT, REQUEST_TIMEOUT, DB_PATH
import db as dbm

log = logging.getLogger("tustus.logic")

PRICE_PAT = re.compile(r'(?P<curr>[$₪])\s*[: ]?\s*(?P<val>\d+(?:[.,]\d+)?)')

def _guess_price(text: str) -> Tuple[str, float] | tuple[None,None]:
    m = PRICE_PAT.search(text.replace("ש\"ח","₪").replace("ש״ח","₪").replace("שח","₪"))
    if not m:
        return (None, None)
    curr = m.group("curr")
    val = float(m.group("val").replace(",","."))
    return (curr, val)

def _scrape_items() -> List[Tuple[str,float,str,str]]:
    headers = {"User-Agent": USER_AGENT}
    r = requests.get(URL, headers=headers, timeout=REQUEST_TIMEOUT)
    r.raise_for_status()
    soup = BS(r.text, "lxml")
    items: List[Tuple[str,float,str,str]] = []

    # Very defensive scraping: look for cards/rows with both destination and price
    candidates = soup.find_all(['div','li','tr','a','span'], string=True)
    for node in candidates:
        t = node.get_text(" ", strip=True)
        if not t or len(t) < 3:
            continue
        # crude destination heuristic: has a dash or a word in Hebrew/Latin
        if any(x in t for x in ["יוון","רודוס","אתונה","קפריס","ברצלונה"]) or re.search(r'[A-Za-z]{3,}', t):
            curr, val = _guess_price(t)
            if curr is not None:
                url = node.get("href") or URL
                dest = t.split("—")[0].split("-")[0].strip()
                items.append((dest, val, curr, url))
    # deduplicate
    seen=set()
    uniq=[]
    for d,p,c,u in items:
        key=(d,p,c,u)
        if key in seen: continue
        seen.add(key); uniq.append((d,p,c,u))
    return uniq

def monitor_job(conn: sqlite3.Connection | None = None, app=None) -> tuple[int,int]:
    """Scrape and upsert. Returns (inserted, updated)."""
    close_local = False
    if conn is None:
        conn = dbm.get_conn(DB_PATH); close_local = True
    try:
        items = _scrape_items()
        ins, upd = dbm.upsert_items(conn, items)
        log.info("monitor_job: scraped=%d inserted=%d updated=%d", len(items), ins, upd)
        return ins, upd
    finally:
        if close_local:
            conn.close()

async def run_monitor(conn: sqlite3.Connection, app=None):
    # run sync monitor in a worker thread BUT open a fresh connection inside the thread
    def _worker():
        local = dbm.get_conn(DB_PATH)
        try:
            return monitor_job(local, app)
        finally:
            local.close()
    return await asyncio.to_thread(_worker)
