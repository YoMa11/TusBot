from __future__ import annotations
import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import BadRequest
import db

from telegram_view import main_menu_markup

log = logging.getLogger("tustus.handlers")

WELCOME = "תפריט ראשי"

async def _render_summary(context: ContextTypes.DEFAULT_TYPE) -> str:
    conn = db.get_conn()
    totals = db.totals(conn)
    conn.close()
    # one line summary: counts per currency
    parts = [f"סה\"כ: {totals['total']}"]
    for curr, c in totals['by_currency'].items():
        sym = curr or "?"
        parts.append(f"{sym}: {c}")
    return " | ".join(parts)

async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = f"{WELCOME}"
    summary = await _render_summary(context)
    try:
        await update.effective_message.reply_text(
            text, reply_markup=main_menu_markup()
        )
        # then edit to add summary rows (keeps UX compact)
        await update.effective_message.reply_text(summary)
    except BadRequest as e:
        if "Message is not modified" not in str(e):
            raise

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    summary = await _render_summary(context)
    try:
        await q.edit_message_text(WELCOME, reply_markup=main_menu_markup())
        await q.message.reply_text(summary)
    except BadRequest as e:
        if "Message is not modified" not in str(e):
            raise
