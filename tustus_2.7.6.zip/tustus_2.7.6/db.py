from __future__ import annotations
import sqlite3, logging, os
from typing import Iterable, Tuple, List, Optional

from config import DB_PATH

log = logging.getLogger("tustus.db")

def get_conn(db_path: str | None = None) -> sqlite3.Connection:
    p = db_path or DB_PATH
    conn = sqlite3.connect(p, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    with conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS show_item (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            destination TEXT NOT NULL,
            price REAL,
            currency TEXT,
            url TEXT,
            last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    return conn

def upsert_items(conn: sqlite3.Connection, rows: Iterable[Tuple[str, float, str, str]]) -> Tuple[int,int]:
    inserted = updated = 0
    with conn:
        for dest, price, curr, url in rows:
            cur = conn.execute("""SELECT id FROM show_item
                                  WHERE destination=? AND price IS ? AND currency IS ? AND url IS ?""",
                               (dest, price, curr, url))
            r = cur.fetchone()
            if r:
                conn.execute("""UPDATE show_item SET last_seen=CURRENT_TIMESTAMP
                               WHERE id=?""", (r[0],))
                updated += 1
            else:
                conn.execute("""INSERT INTO show_item(destination,price,currency,url)
                               VALUES(?,?,?,?)""", (dest, price, curr, url))
                inserted += 1
    return inserted, updated

def distinct_prices(conn: sqlite3.Connection) -> List[Tuple[str,float]]:
    cur = conn.execute("""SELECT currency, price FROM show_item
                          WHERE price IS NOT NULL AND currency IS NOT NULL
                          GROUP BY currency, price
                          ORDER BY currency, price""")
    return [(row['currency'] or '', float(row['price'])) for row in cur.fetchall()]

def distinct_destinations(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute("""SELECT destination FROM show_item GROUP BY destination ORDER BY destination""")
    return [row['destination'] for row in cur.fetchall()]

def totals(conn: sqlite3.Connection) -> dict:
    cur = conn.execute("""SELECT currency, COUNT(*) c FROM show_item GROUP BY currency""")
    by_curr = { (row['currency'] or ''): row['c'] for row in cur.fetchall() }
    cur2 = conn.execute("""SELECT COUNT(*) c FROM show_item""")
    total = cur2.fetchone()['c']
    return {'total': total, 'by_currency': by_curr}
