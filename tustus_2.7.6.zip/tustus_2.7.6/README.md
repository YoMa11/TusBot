# tustus_2.7.6

- אל תשנה את `config.py` ידנית פרט ל־BOT_TOKEN/URL/INTERVAL לפי הצורך.
- הפעלה:
  ```bash
  bash ./botctl.sh setup
  bash ./botctl.sh start
  tail -f bot.log
  ```
- התפריט בטלגרם: אופציה 1 (טאבים בראש + שורת סיכום).
