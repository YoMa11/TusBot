from __future__ import annotations
from telegram import InlineKeyboardMarkup, InlineKeyboardButton

def main_menu_markup():
    # Top tabs
    row_tabs = [
        InlineKeyboardButton("כל הטיסות", callback_data="tab:all"),
        InlineKeyboardButton("יעדים", callback_data="tab:dest"),
        InlineKeyboardButton("מחירים", callback_data="tab:price"),
    ]
    rows = [row_tabs]
    # summary rows will be injected by handlers with edit_message_text
    return InlineKeyboardMarkup([row_tabs])
