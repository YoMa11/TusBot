#!/usr/bin/env bash
bash ./botctl.sh start
