-- schema for flights
CREATE TABLE IF NOT EXISTS show_item (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  destination TEXT NOT NULL,
  price REAL,
  currency TEXT,
  url TEXT,
  last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_show_item_destination ON show_item(destination);
CREATE INDEX IF NOT EXISTS idx_show_item_last_seen ON show_item(last_seen);
