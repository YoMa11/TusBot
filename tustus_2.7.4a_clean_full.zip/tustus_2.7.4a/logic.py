from __future__ import annotations
import logging, re, sqlite3, time
import requests
from bs4 import BeautifulSoup

import config
import db as DB

__file_version__ = "tustus_2.7.4a"

log = logging.getLogger("tustus.logic")

CURRENCY_SIGNS = ["₪", "$", "€"]

def _parse_price_and_currency(txt: str) -> tuple[float|None, str|None]:
    txt = txt.strip()
    currency = None
    for sign in CURRENCY_SIGNS:
        if sign in txt:
            currency = sign
            break
    # numbers like 1,234 or 1 234 or 1234.56
    m = re.search(r"(\d[\d,\. ]*)", txt)
    if not m:
        return None, currency
    num = m.group(1).replace(",", "").replace(" ", "")
    try:
        return float(num), currency
    except Exception:
        return None, currency

def _extract_cards(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    # very tolerant selector set
    candidates = soup.select(".card, .item, .flight, .result, .offer, .tile")
    items = []
    for el in candidates:
        text = el.get_text(" ", strip=True)
        if not text: 
            continue
        # heuristic destination: first big text chunk
        dest = None
        # try by known labels
        for dlab in ["יעד", "Destination", "יעדים"]:
            lab = el.find(string=re.compile(dlab))
            if lab:
                # neighbor text
                dest = lab.parent.get_text(" ", strip=True)
                break
        if not dest:
            # fallback: first heading-like
            h = el.select_one("h1,h2,h3,.title,.destination")
            dest = h.get_text(" ", strip=True) if h else text.split(" ")[0:3]
            if isinstance(dest, list):
                dest = " ".join(dest)

        price, currency = None, None
        price_el = None
        for sel in [".price",".amount",".cost",".fare"]:
            price_el = el.select_one(sel)
            if price_el: break
        if price_el:
            price, currency = _parse_price_and_currency(price_el.get_text(" ", strip=True))
        else:
            # fallback: search in full text
            price, currency = _parse_price_and_currency(text)

        items.append({
            "destination": dest or "לא ידוע",
            "price": price,
            "currency": currency,
            "url": config.URL
        })
    return items

async def run_monitor(conn: sqlite3.Connection, app) -> None:
    """Entry called by JobQueue every INTERVAL seconds."""
    try:
        resp = requests.get(config.URL, timeout=config.REQUEST_TIMEOUT, headers={"User-Agent": config.USER_AGENT})
        resp.raise_for_status()
        cards = _extract_cards(resp.text)
        ins = 0
        for c in cards:
            DB.upsert_show_item(conn, c["destination"], c["price"], c["currency"], c["url"])
            ins += 1
        log.info("show_item cards parsed: %d | inserted=%d", len(cards), ins)
    except Exception:
        log.exception("monitor_job raised")
