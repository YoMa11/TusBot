# tustus_2.7.4a clean full

- JobQueue רץ כל INTERVAL שניות ומזין את ה-DB מה-URL שב-config.py.
- ההנדלרים בונים תפריט ראשי מדאטה אמיתי (DB). מטפלים ב-Telegram BadRequest: Message is not modified.
- אין שינויי קונפיגורציה סמויים. BOT_TOKEN/URL/DB_PATH/INTERVAL נשארו כפי שנתת.
