# @@file_version: v2.4.7
from __future__ import annotations
import sqlite3

def ensure_user(conn: sqlite3.Connection, chat_id: int):
    conn.execute("""
      CREATE TABLE IF NOT EXISTS users(
        chat_id INTEGER PRIMARY KEY,
        created_at TEXT DEFAULT (datetime('now')),
        last_seen_at TEXT DEFAULT (datetime('now')),
        subscribed INTEGER DEFAULT 1
      )""")
    conn.execute("""
      CREATE TABLE IF NOT EXISTS user_prefs(
        chat_id INTEGER PRIMARY KEY,
        destinations_csv TEXT DEFAULT '',
        max_price INTEGER,
        min_seats INTEGER DEFAULT 1,
        min_days INTEGER,
        max_days INTEGER,
        date_start TEXT,
        date_end TEXT,
        show_new INTEGER DEFAULT 1,
        show_active INTEGER DEFAULT 1,
        show_removed INTEGER DEFAULT 0,
        quiet_mode INTEGER DEFAULT 0,
        max_items INTEGER DEFAULT 30,
        show_active_time INTEGER DEFAULT 1,
        updated_at TEXT DEFAULT (datetime('now'))
      )""")
    conn.execute("""
      CREATE TABLE IF NOT EXISTS saved_flights(
        chat_id INTEGER NOT NULL,
        flight_key TEXT NOT NULL,
        saved_at TEXT DEFAULT (datetime('now')),
        PRIMARY KEY(chat_id, flight_key)
      )""")
    conn.commit()

def ensure_schema(conn: sqlite3.Connection):
    for sql in [
        "ALTER TABLE flights ADD COLUMN status TEXT DEFAULT 'active'",
        "ALTER TABLE flights ADD COLUMN currency TEXT",
        "ALTER TABLE flights ADD COLUMN price_text TEXT",
    ]:
        try: conn.execute(sql)
        except Exception: pass
    conn.commit()

def ensure_price_catalog(conn: sqlite3.Connection):
    conn.execute("""
    CREATE TABLE IF NOT EXISTS price_catalog(
      currency  TEXT NOT NULL,
      value     INTEGER NOT NULL,
      first_seen TEXT DEFAULT (datetime('now')),
      last_seen  TEXT DEFAULT (datetime('now')),
      PRIMARY KEY(currency, value)
    )""")
    conn.execute("""
      INSERT OR IGNORE INTO price_catalog(currency, value)
      SELECT
        COALESCE(currency,
                 CASE WHEN instr(COALESCE(price_text,''),'$')>0 THEN 'USD' ELSE 'ILS' END),
        price
      FROM flights
      WHERE price IS NOT NULL
    """)
    conn.execute("""
      UPDATE price_catalog
         SET last_seen = datetime('now')
       WHERE (currency,value) IN (
             SELECT COALESCE(currency,
                              CASE WHEN instr(COALESCE(price_text,''),'$')>0 THEN 'USD' ELSE 'ILS' END),
                    price
               FROM flights
              WHERE price IS NOT NULL)
    """)
    conn.commit()

def get_price_catalog(conn: sqlite3.Connection):
    ensure_price_catalog(conn)
    cur = conn.execute("""
      SELECT currency, value
        FROM price_catalog
    ORDER BY (currency='ILS') DESC, value ASC
    """)
    out = []
    for c, v in cur.fetchall():
        sym = "$" if (c or "").upper() == "USD" else "₪"
        out.append(f"{v}{sym}")
    return out

def toggle_saved(conn: sqlite3.Connection, chat_id: int, flight_key: str) -> bool:
    cur = conn.execute(
        "SELECT 1 FROM saved_flights WHERE chat_id=? AND flight_key=?",
        (chat_id, flight_key))
    if cur.fetchone():
        conn.execute("DELETE FROM saved_flights WHERE chat_id=? AND flight_key=?",
                     (chat_id, flight_key))
        conn.commit()
        return False
    conn.execute("INSERT OR IGNORE INTO saved_flights(chat_id, flight_key) VALUES(?,?)",
                 (chat_id, flight_key))
    conn.commit()
    return True

def get_saved_flights(conn: sqlite3.Connection, chat_id: int):
    conn.row_factory = sqlite3.Row
    cur = conn.execute("""
        SELECT f.*
          FROM saved_flights s
          JOIN flights f ON f.flight_key = s.flight_key
         WHERE s.chat_id=?
      ORDER BY datetime(COALESCE(f.scraped_at, f.first_seen, '1970-01-01T00:00:00')) DESC
         LIMIT 200
    """, (chat_id,))
    return [dict(r) for r in cur.fetchall()]
