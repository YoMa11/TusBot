# @@file_version: v2.4.7
from __future__ import annotations
import logging, sqlite3
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler
import config as cfg
from handlers import handle_start, handle_callback
from notify import notify_changes
from db import ensure_schema, ensure_price_catalog

logging.basicConfig(level=getattr(logging, cfg.LOG_LEVEL, "INFO"))
log = logging.getLogger("tusbot")

def _conn():
    conn = sqlite3.connect(cfg.DB_FILE)
    conn.row_factory = sqlite3.Row
    ensure_schema(conn)
    ensure_price_catalog(conn)
    return conn

async def _start_wrapper(update, context):
    conn = _conn()
    try:
        await handle_start(update, context, conn, cfg)
    finally:
        conn.close()

async def _cb_wrapper(update, context):
    conn = _conn()
    try:
        await handle_callback(update, context, conn, cfg)
    finally:
        conn.close()

async def _tick_notify(ctx):
    conn = _conn()
    try:
        await notify_changes(conn, ctx.application.bot)
    finally:
        conn.close()

def main():
    app = ApplicationBuilder().token(cfg.BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", _start_wrapper))
    app.add_handler(CallbackQueryHandler(_cb_wrapper))
    app.job_queue.run_repeating(_tick_notify, interval=cfg.INTERVAL, first=30)
    log.info("🚀 tusbot v2.4.7 up. DB=%s, interval=%ss", cfg.DB_FILE, cfg.INTERVAL)
    app.run_polling()

if __name__ == "__main__":
    main()
