# @@file_version: v2.4.7
from __future__ import annotations
import html, math
from typing import List
from datetime import datetime
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
from db import get_price_catalog

def _center_title(txt: str) -> str:
    return f"<b>{html.escape(txt)}</b>"

def main_menu_kb():
    rows = [
        [InlineKeyboardButton("כל הטיסות 🔎", callback_data="SHOW_ALL"),
         InlineKeyboardButton("לפי העדפות 🎯", callback_data="BY_PREFS"),
         InlineKeyboardButton("שמורים ⭐", callback_data="SAVED")],
        [InlineKeyboardButton("יעדים 🎯", callback_data="DESTS"),
         InlineKeyboardButton("מחיר 💸", callback_data="PRICE"),
         InlineKeyboardButton("מושבים 🪑", callback_data="SEATS")],
        [InlineKeyboardButton("תאריכים 🗓", callback_data="DATES"),
         InlineKeyboardButton("אורך טיול 🧾", callback_data="TRIP"),
         InlineKeyboardButton("נראות 👀", callback_data="VIS")],
        [InlineKeyboardButton("סיכום לפי יעד 📊", callback_data="SUMMARY"),
         InlineKeyboardButton("מצב שקט 🔕", callback_data="QUIET_TOGGLE"),
         InlineKeyboardButton("איפוס ♻️", callback_data="RESET")],
        [InlineKeyboardButton("בית 🏠", callback_data="HOME")]
    ]
    return InlineKeyboardMarkup(rows)

def feed_nav_kb():
    return InlineKeyboardMarkup([[InlineKeyboardButton("בית 🏠", callback_data="HOME"),
                                  InlineKeyboardButton("לפי העדפות 🎯", callback_data="BY_PREFS"),
                                  InlineKeyboardButton("שמורים ⭐", callback_data="SAVED")]])

def _truncate(s: str, n: int = 18) -> str:
    return s if len(s) <= n else s[: n - 1] + "…"

def destinations_page(selected_csv: str, page: int, per_page: int, all_dests: List[str]):
    selected = set(d.strip() for d in (selected_csv or "").split(",") if d.strip())
    all_sorted = sorted(all_dests, key=lambda x: x)
    import math as _m
    total_pages = max(1, _m.ceil(len(all_sorted) / per_page))
    page = max(1, min(page, total_pages))
    start = (page - 1) * per_page
    chunk = all_sorted[start : start + per_page]

    rows = [[InlineKeyboardButton("🟩 הכל", callback_data="DEST_ALL_TOGGLE"),
             InlineKeyboardButton("שמור וחזור ✅", callback_data="DEST_SAVE")]]

    row = []
    for d in chunk:
        mark = "✅ " if d in selected else "⬜️ "
        row.append(InlineKeyboardButton(f"{mark}{_truncate(d)}", callback_data=f"DEST_TOGGLE::{d}|PAGE_{page}"))
        if len(row) == 3:
            rows.append(row); row = []
    if row: rows.append(row)

    rows.append([InlineKeyboardButton(f"{page}/{total_pages}", callback_data="DESTS_NOP")])
    rows.append([InlineKeyboardButton("בית 🏠", callback_data="HOME")])
    return InlineKeyboardMarkup(rows)

def price_menu_kb(prefs, conn=None):
    try: values = get_price_catalog(conn) if conn else []
    except Exception: values = []
    if not values:
        values = ["100$","150$","300$","200₪"]
    rows, row = [], []
    for p in values:
        row.append(InlineKeyboardButton(p, callback_data=f"PRICE_SET_{p}"))
        if len(row) == 4:
            rows.append(row); row = []
    if row: rows.append(row)
    rows.append([InlineKeyboardButton("נקה", callback_data="PRICE_CLEAR"),
                 InlineKeyboardButton("בית 🏠", callback_data="HOME")])
    return InlineKeyboardMarkup(rows)

def seats_menu_kb(prefs):
    rows = [[InlineKeyboardButton(str(n), callback_data=f"SEATS_SET_{n}") for n in [1,2,3,4,5]]]
    rows.append([InlineKeyboardButton("נקה", callback_data="SEATS_CLEAR"),
                 InlineKeyboardButton("בית 🏠", callback_data="HOME")])
    return InlineKeyboardMarkup(rows)

def dates_menu_kb():
    rows = [[InlineKeyboardButton("שבוע קדימה", callback_data="DATES_WEEK"),
             InlineKeyboardButton("חודש קדימה", callback_data="DATES_MONTH")],
            [InlineKeyboardButton("נקה", callback_data="DATES_CLEAR"),
             InlineKeyboardButton("בית 🏠", callback_data="HOME")]]
    return InlineKeyboardMarkup(rows)

def trip_len_menu_kb():
    opts = ["2-3","3-4","4-5","5-7","7-10","10-14"]
    rows, row = [], []
    for o in opts:
        row.append(InlineKeyboardButton(o, callback_data=f"TRIP_SET_{o}"))
        if len(row)==3: rows.append(row); row=[]
    if row: rows.append(row)
    rows.append([InlineKeyboardButton("נקה", callback_data="TRIP_CLEAR"),
                 InlineKeyboardButton("בית 🏠", callback_data="HOME")])
    return InlineKeyboardMarkup(rows)

def visibility_menu_kb(prefs):
    def box(flag): return "✅" if int(prefs.get(flag) or 0) else "⬜️"
    rows = [[InlineKeyboardButton(f"חדשים {box('show_new')}", callback_data="VIS_TOGGLE_NEW"),
             InlineKeyboardButton(f"פעילים {box('show_active')}", callback_data="VIS_TOGGLE_ACTIVE")],
            [InlineKeyboardButton(f"הוסרו {box('show_removed')}", callback_data="VIS_TOGGLE_REMOVED"),
             InlineKeyboardButton("בית 🏠", callback_data="HOME")]]
    return InlineKeyboardMarkup(rows)

FLAGS = {"יוון":"🇬🇷","קפריסין":"🇨🇾","ספרד":"🇪🇸","מונטנגרו":"🇲🇪","גאורגיה":"🇬🇪",
         "איטליה":"🇮🇹","צרפת":"🇫🇷","פורטוגל":"🇵🇹","רודוס":"🇬🇷","כרתים":"🇬🇷",
         "קורפו":"🇬🇷","אתונה":"🇬🇷"}
def flag_for(dest: str) -> str:
    for k,v in FLAGS.items():
        if k in (dest or ""): return v
    return "🌍"

def _arrow(a: str, b: str) -> str:
    try:
        t1 = datetime.strptime(a, "%H:%M"); t2 = datetime.strptime(b, "%H:%M")
        return "→" if t2 >= t1 else "←"
    except Exception:
        return "→"

def _fmt_price_raw(f: dict) -> str:
    if f.get("price_text"): return f["price_text"]
    v = f.get("price")
    if v is None: return "—"
    sym = "$" if (f.get("currency") or "").upper()=="USD" else "₪"
    return f"{v}{sym}"

def _fmt_seats(f: dict) -> str:
    s = f.get("seats"); return str(s) if s else "🎟️?"

def _age_text(f: dict) -> str:
    fs = f.get("first_seen") or f.get("scraped_at")
    if not fs: return ""
    try:
        from datetime import datetime as _dt
        dt = _dt.fromisoformat(fs)
    except Exception:
        return ""
    delta = datetime.utcnow() - dt
    h = delta.days*24 + delta.seconds//3600
    m = (delta.seconds%3600)//60
    return f"⏱ פעילה: {h} שע' {m} דק'"

def format_flight_card(f: dict, show_removed: bool=False) -> str:
    removed = (f.get("status") == "removed") or show_removed
    dest = (f.get("destination") or f.get("name") or "יעד").strip()
    url  = f.get("link") or "#"
    go_d, go_t1, go_t2 = f.get("go_date") or "", f.get("go_depart") or "", f.get("go_arrive") or ""
    bk_d, bk_t1, bk_t2 = f.get("back_date") or "", f.get("back_depart") or "", f.get("back_arrive") or ""
    arr1, arr2 = _arrow(go_t1, go_t2), _arrow(bk_t1, bk_t2)
    price, seats, age = _fmt_price_raw(f), _fmt_seats(f), _age_text(f)
    badge_removed = "  <b>🚫 הוסר</b>" if removed else ""
    line1 = f"<b><a href=\"{html.escape(url)}\">{html.escape(dest)}</a></b>{badge_removed} 🌍"
    line2 = f"{go_t1} {arr1} {go_t2} · {go_d}"
    line3 = f"{bk_t1} {arr2} {bk_t2} · {bk_d}"
    line4 = f"— מושבים: {seats}  ·  מחיר: {price}  🪙"
    line5 = age
    return "\n".join([line1, line2, line3, line4, line5])

MAX_TG = 4000
def chunk_messages(cards: List[str], header: str=""):
    out, cur = [], (header.strip()+"\n\n" if header else "")
    for c in cards:
        block = (c.strip()+"\n\n")
        if len(cur)+len(block) > MAX_TG:
            out.append(cur.rstrip()); cur = ""
        cur += block
    if cur.strip(): out.append(cur.rstrip())
    return out

def paginate_cards(flights: List[dict], prefs: dict, page: int=1, page_size: int=10, show_active_time: bool=True):
    cards = [format_flight_card(f) for f in flights]
    total = max(1, math.ceil(len(cards)/page_size))
    page = max(1, min(page, total))
    start = (page-1)*page_size
    chunk = cards[start:start+page_size]
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("◀️", callback_data=f"PAGE_{page-1}" if page>1 else "NOP"),
                                InlineKeyboardButton(f"{page}/{total}", callback_data="NOP"),
                                InlineKeyboardButton("▶️", callback_data=f"PAGE_{page+1}" if page<total else "NOP")]])
    return chunk, kb, page, total
