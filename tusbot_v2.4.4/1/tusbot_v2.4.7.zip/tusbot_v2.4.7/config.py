# @@file_version: v2.4.7
"""Runtime configuration for tusbot."""
BOT_TOKEN = "PUT_YOUR_TELEGRAM_BOT_TOKEN_HERE"
DB_FILE = "tustus.db"
INTERVAL = 900
LOG_LEVEL = "INFO"
