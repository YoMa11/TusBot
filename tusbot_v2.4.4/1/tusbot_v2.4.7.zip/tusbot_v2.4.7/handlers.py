# @@file_version: v2.4.7
from __future__ import annotations
import re, sqlite3, html
from datetime import datetime, timedelta
from typing import List, Dict, Any
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.constants import ParseMode
from telegram.error import BadRequest
from telegram.ext import ContextTypes
from db import toggle_saved, get_saved_flights, ensure_user
from telegram_view import (
    main_menu_kb, destinations_page, price_menu_kb, seats_menu_kb, dates_menu_kb,
    trip_len_menu_kb, visibility_menu_kb, feed_nav_kb, format_flight_card,
    chunk_messages, paginate_cards, _center_title, flag_for
)

def _row_to_dict(r: sqlite3.Row) -> Dict[str, Any]:
    return {k: r[k] for k in r.keys()}

def get_prefs(conn: sqlite3.Connection, chat_id: int) -> Dict[str, Any]:
    r = conn.execute("SELECT * FROM user_prefs WHERE chat_id=?", (chat_id,)).fetchone()
    return _row_to_dict(r) if r else {}

def update_prefs(conn: sqlite3.Connection, chat_id: int, **fields):
    if not fields: return
    sets = ", ".join([f"{k}=?" for k in fields])
    params = list(fields.values()) + [chat_id]
    conn.execute(f"UPDATE user_prefs SET {sets}, updated_at=datetime('now') WHERE chat_id=?", params)
    conn.commit()

def reset_prefs(conn: sqlite3.Connection, chat_id: int):
    conn.execute("""
      UPDATE user_prefs SET
        destinations_csv='', max_price=NULL, min_seats=1,
        min_days=NULL, max_days=NULL, date_start=NULL, date_end=NULL,
        show_new=1, show_active=1, show_removed=0, quiet_mode=0,
        max_items=30, show_active_time=1, updated_at=datetime('now')
      WHERE chat_id=?
    """, (chat_id,)); conn.commit()

def get_all_destinations(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute("SELECT DISTINCT destination FROM flights WHERE destination IS NOT NULL AND destination<>'' ORDER BY destination COLLATE NOCASE")
    return [r[0] for r in cur.fetchall()]

def query_flights_all(conn: sqlite3.Connection, limit: int = 30) -> List[Dict[str, Any]]:
    cur = conn.execute("""
    SELECT id, name, destination, link, price, currency, price_text, go_date, go_depart, go_arrive,
           back_date, back_depart, back_arrive, seats, status, first_seen, scraped_at, flight_key
      FROM flights
  ORDER BY datetime(COALESCE(scraped_at, first_seen, '1970-01-01T00:00:00')) DESC
     LIMIT ?
    """, (limit,))
    return [_row_to_dict(r) for r in cur.fetchall()]

def query_flights_by_prefs(conn: sqlite3.Connection, prefs: Dict[str, Any], limit: int = 30) -> List[Dict[str, Any]]:
    where, params = [], []
    dests_csv = (prefs.get("destinations_csv") or "").strip()
    if dests_csv:
        dests = [d.strip() for d in dests_csv.split(",") if d.strip()]
        if dests:
            where.append("(" + " OR ".join(["destination = ?" for _ in dests]) + ")"); params.extend(dests)
    max_price = prefs.get("max_price")
    if max_price not in (None, "", 0, "0"):
        where.append("price IS NOT NULL AND price <= ?"); params.append(int(max_price))
    min_seats = prefs.get("min_seats")
    if min_seats not in (None, "", 0, "0"):
        where.append("(seats IS NULL OR seats >= ?)"); params.append(int(min_seats))
    date_start = prefs.get("date_start"); date_end = prefs.get("date_end")
    if date_start: where.append("(go_date IS NOT NULL AND go_date >= ?)"); params.append(date_start)
    if date_end:   where.append("(go_date IS NOT NULL AND go_date <= ?)"); params.append(date_end)
    min_days = prefs.get("min_days"); max_days = prefs.get("max_days")
    if min_days or max_days:
        where.append("(go_date IS NOT NULL AND back_date IS NOT NULL)")
        if min_days: where.append("(julianday(back_date) - julianday(go_date) + 1) >= ?"); params.append(int(min_days))
        if max_days: where.append("(julianday(back_date) - julianday(go_date) + 1) <= ?"); params.append(int(max_days))
    where_sql = "WHERE " + " AND ".join(where) if where else ""
    sql = f"""
    SELECT id, name, destination, link, price, currency, price_text, go_date, go_depart, go_arrive,
           back_date, back_depart, back_arrive, seats, status, first_seen, scraped_at, flight_key
      FROM flights
      {where_sql}
  ORDER BY datetime(COALESCE(scraped_at, first_seen, '1970-01-01T00:00:00')) DESC
     LIMIT ?
    """
    params.append(limit)
    cur = conn.execute(sql, tuple(params))
    return [_row_to_dict(r) for r in cur.fetchall()]

def query_saved(conn: sqlite3.Connection, chat_id: int, limit: int = 30) -> List[Dict[str, Any]]:
    cur = conn.execute("""
    SELECT f.* FROM saved_flights s
    JOIN flights f ON f.flight_key = s.flight_key
    WHERE s.chat_id=?
    ORDER BY datetime(COALESCE(f.scraped_at, f.first_seen, '1970-01-01T00:00:00')) DESC
    LIMIT ?
    """, (chat_id, limit))
    return [_row_to_dict(r) for r in cur.fetchall()]

async def _send_feed(update: Update, context: ContextTypes.DEFAULT_TYPE, flights: List[Dict[str, Any]], header: str):
    if not flights:
        text = header + "\n\nלא נמצאו טיסות מתאימות כרגע."
        q = update.callback_query
        if q:
            try: await q.answer()
            except Exception: pass
            try:
                await q.edit_message_text(text, reply_markup=feed_nav_kb(),
                                          parse_mode=ParseMode.HTML, disable_web_page_preview=True)
                return
            except BadRequest: pass
        await context.bot.send_message(chat_id=update.effective_chat.id, text=text,
                                       reply_markup=feed_nav_kb(), parse_mode=ParseMode.HTML,
                                       disable_web_page_preview=True)
        return
    cards = [format_flight_card(f) for f in flights]
    chunks = chunk_messages(cards, header=header)
    q = update.callback_query
    if q:
        try: await q.answer()
        except Exception: pass
    first = True
    for ch in chunks:
        if q and first:
            try:
                await q.edit_message_text(ch, reply_markup=feed_nav_kb(),
                                          parse_mode=ParseMode.HTML, disable_web_page_preview=True)
                first = False
                continue
            except BadRequest: pass
        await context.bot.send_message(chat_id=update.effective_chat.id, text=ch,
                                       reply_markup=feed_nav_kb(), parse_mode=ParseMode.HTML,
                                       disable_web_page_preview=True)
        first = False

async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE, conn: sqlite3.Connection, cfg):
    chat_id = update.effective_chat.id
    ensure_user(conn, chat_id)
    await context.bot.send_message(chat_id=chat_id, text="🏠 תפריט ראשי", reply_markup=main_menu_kb())

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, conn: sqlite3.Connection, cfg):
    chat_id = update.effective_chat.id
    ensure_user(conn, chat_id)
    prefs = get_prefs(conn, chat_id)
    max_items = int(prefs.get("max_items") or 30)
    q = update.callback_query
    msg = update.effective_message
    data = (q.data if q else (msg.text if (msg and msg.text) else "")) or ""
    key = data.upper().strip()

    if q and data.startswith("SAVE|"):
        _, flight_key = data.split("|", 1)
        saved_now = toggle_saved(conn, update.effective_user.id, flight_key)
        await q.answer("✅ נשמר" if saved_now else "❎ הוסר", show_alert=False)
        return

    if q and data.startswith("SAVED"):
        flights = get_saved_flights(conn, update.effective_user.id)
        if not flights:
            try: await q.edit_message_text("אין טיסות שמורות עדיין.", parse_mode=ParseMode.HTML)
            except BadRequest: await context.bot.send_message(chat_id=chat_id, text="אין טיסות שמורות עדיין.", parse_mode=ParseMode.HTML)
            return
        cards, nav_kb, page, total = paginate_cards(flights, {"show_active_time":1}, page=1, page_size=10, show_active_time=True)
        try: await q.edit_message_text("\n\n".join(cards), reply_markup=nav_kb, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        except BadRequest: await context.bot.send_message(chat_id=chat_id, text="\n\n".join(cards), reply_markup=nav_kb, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        return

    if key in ("HOME","START","/START","בית","תפריט"):
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text("🏠 תפריט ראשי", reply_markup=main_menu_kb()); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text="🏠 תפריט ראשי", reply_markup=main_menu_kb()); return

    if key in ("SHOW_ALL","SEND_NOW","ALL","כל הטיסות"):
        flights = query_flights_all(conn, limit=max_items)
        await _send_feed(update, context, flights, header="👀 כל הדילים (ללא סינון)")
        return

    if key in ("BY_PREFS","APPLY_PREFS","SHOW_PREFS"):
        flights = query_flights_by_prefs(conn, prefs, limit=max_items)
        await _send_feed(update, context, flights, header="🎯 דילים לפי העדפות")
        return

    if key.startswith("SUMMARY") or key == "סיכום לפי יעד":
        row = conn.execute("SELECT MAX(scraped_at) FROM flights").fetchone()
        last_ts = row[0] if row else None
        sql = """SELECT destination, COUNT(*) c FROM flights
                 WHERE destination IS NOT NULL AND destination<>'' {flt}
                 GROUP BY destination ORDER BY c DESC, destination LIMIT 50"""
        flt = "AND scraped_at=?" if last_ts else ""
        cur = conn.execute(sql.format(flt=flt), (last_ts,) if last_ts else ())
        rows = cur.fetchall()
        if not rows:
            txt = "אין כרגע טיסות זמינות לריצה האחרונה."
        else:
            lines = ["<b>📊 סיכום לפי יעד (זמין כרגע):</b>",""]
            for i,(d,c) in enumerate(rows,1):
                from telegram_view import flag_for
                flag = flag_for(d)
                medal = "🥇 " if i==1 else "🥈 " if i==2 else "🥉 " if i==3 else ""
                lines.append(f"{medal}{flag} {d} — {c}")
            txt = "\n".join(lines)
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(txt, reply_markup=feed_nav_kb(), parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=txt, reply_markup=feed_nav_kb(), parse_mode=ParseMode.HTML); return

    if key in ("RESET","איפוס"):
        reset_prefs(conn, chat_id)
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text("♻️ ההגדרות אופסו. חזרה לתפריט.", reply_markup=main_menu_kb()); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text="♻️ ההגדרות אופסו.", reply_markup=main_menu_kb()); return

    if key in ("QUIET","QUIET_TOGGLE","מצב שקט"):
        new_val = 0 if int(prefs.get("quiet_mode") or 0) else 1
        update_prefs(conn, chat_id, quiet_mode=new_val)
        msg_txt = "🔕 מצב שקט הופעל — תקבל רק התראות קריטיות" if new_val else "🔔 מצב שקט בוטל — תחזור לקבל הכל"
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(msg_txt, reply_markup=main_menu_kb()); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=msg_txt, reply_markup=main_menu_kb()); return

    if key in ("DESTS","יעדים"):
        dests_all = get_all_destinations(conn)
        page = 1
        header = _center_title("בחר/י יעדים (בחירה מרובה) — ✅/⬜️")
        kb = destinations_page(prefs.get("destinations_csv") or "", page, 21, dests_all)
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(header, reply_markup=kb, parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=header, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if key.startswith("DESTS_PAGE_"):
        dests_all = get_all_destinations(conn)
        try: page = int(key.split("_")[-1])
        except Exception: page = 1
        header = _center_title("בחר/י יעדים (בחירה מרובה) — ✅/⬜️")
        kb = destinations_page(prefs.get("destinations_csv") or "", page, 21, dests_all)
        await q.edit_message_text(header, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if key == "DEST_ALL_TOGGLE":
        all_dests = get_all_destinations(conn)
        cur = (prefs.get("destinations_csv") or "").strip()
        selected = [d for d in cur.split(",") if d.strip()]
        if len(selected) >= len(all_dests):
            from telegram_view import main_menu_kb
            update_prefs(conn, chat_id, destinations_csv="")
            await q.answer("נוקה")
            await q.edit_message_text("🏠 תפריט ראשי", reply_markup=main_menu_kb()); return
        update_prefs(conn, chat_id, destinations_csv=",".join(all_dests))
        await q.answer("✅ כל היעדים סומנו")
        await q.edit_message_text("🏠 תפריט ראשי", reply_markup=main_menu_kb()); return

    if key.startswith("DEST_TOGGLE::"):
        dests_all = get_all_destinations(conn)
        item = data.split("::",1)[1].split("|")[0]
        current = [d for d in (prefs.get("destinations_csv") or "").split(",") if d.strip()]
        if item in current: current = [d for d in current if d != item]
        else: current.append(item)
        csv = ",".join(current)
        update_prefs(conn, chat_id, destinations_csv=csv)
        prefs = get_prefs(conn, chat_id)
        import re as _re
        m = _re.search(r"PAGE_(\d+)$", data or "")
        page = int(m.group(1)) if m else 1
        header = _center_title("בחר/י יעדים (בחירה מרובה) — ✅/⬜️")
        kb = destinations_page(prefs.get("destinations_csv") or "", page, 21, dests_all)
        await q.edit_message_text(header, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if key == "DEST_SAVE":
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text("✅ נשמר. חוזר לתפריט.", reply_markup=main_menu_kb()); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text="✅ נשמר.", reply_markup=main_menu_kb()); return

    if key in ("PRICE","מחיר"):
        kb = price_menu_kb(prefs, conn=conn)
        title = _center_title("מחיר מקסימלי 💸")
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(title, reply_markup=kb, parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=title, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if (q and key.startswith("PRICE_SET_")) or (q and key == "PRICE_CLEAR"):
        if key == "PRICE_CLEAR":
            update_prefs(conn, chat_id, max_price=None)
        else:
            raw = key.split("PRICE_SET_",1)[1]
            digits = re.sub(r"[^0-9]", "", raw)
            val = int(digits) if digits else None
            update_prefs(conn, chat_id, max_price=val)
        await q.edit_message_text("✅ עודכן. חוזר לתפריט.", reply_markup=main_menu_kb()); return

    if key in ("SEATS","מושבים"):
        kb = seats_menu_kb(prefs)
        title = _center_title("מינימום מושבים 🪑")
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(title, reply_markup=kb, parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=title, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if (q and key.startswith("SEATS_SET_")) or (q and key == "SEATS_CLEAR"):
        if key == "SEATS_CLEAR":
            update_prefs(conn, chat_id, min_seats=1)
        else:
            val = int(key.split("_")[-1]); update_prefs(conn, chat_id, min_seats=val)
        await q.edit_message_text("✅ עודכן. חוזר לתפריט.", reply_markup=main_menu_kb()); return

    if key in ("DATES","תאריכים"):
        kb = dates_menu_kb()
        title = _center_title("בחר/י טווח תאריכים 🗓")
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(title, reply_markup=kb, parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=title, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if q and key in ("DATES_WEEK","DATES_MONTH","DATES_CLEAR"):
        today = datetime.utcnow().date()
        if key == "DATES_WEEK":
            ds, de = today.isoformat(), (today + timedelta(days=7)).isoformat()
            update_prefs(conn, chat_id, date_start=ds, date_end=de)
        elif key == "DATES_MONTH":
            ds = today.isoformat()
            nm = (today.replace(day=28) + timedelta(days=4)).replace(day=1)
            de = (nm - timedelta(days=1)).isoformat()
            update_prefs(conn, chat_id, date_start=ds, date_end=de)
        else:
            update_prefs(conn, chat_id, date_start=None, date_end=None)
        await q.edit_message_text("✅ עודכן. חוזר לתפריט.", reply_markup=main_menu_kb()); return

    if (not q) and data and re.match(r"^\d{4}-\d{2}-\d{2},\d{4}-\d{2}-\d{2}$", data):
        ds, de = data.strip().split(",")
        update_prefs(conn, chat_id, date_start=ds, date_end=de)
        await context.bot.send_message(chat_id=chat_id, text="✅ טווח תאריכים נשמר.", reply_markup=main_menu_kb())
        return

    if key in ("TRIP","אורך טיול"):
        kb = trip_len_menu_kb()
        title = _center_title("אורך טיול 🧾")
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(title, reply_markup=kb, parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=title, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if q and (key.startswith("TRIP_SET_") or key == "TRIP_CLEAR"):
        if key == "TRIP_CLEAR":
            update_prefs(conn, chat_id, min_days=None, max_days=None)
        else:
            part = key.split("_")[-1]; lo, hi = part.split("-")
            update_prefs(conn, chat_id, min_days=int(lo), max_days=int(hi))
        await q.edit_message_text("✅ עודכן. חוזר לתפריט.", reply_markup=main_menu_kb()); return

    if key in ("VIS","נראות"):
        kb = visibility_menu_kb(prefs)
        title = _center_title("נראות דילים 👀")
        if q:
            try: await q.answer()
            except Exception: pass
            try: await q.edit_message_text(title, reply_markup=kb, parse_mode=ParseMode.HTML); return
            except BadRequest: pass
        await context.bot.send_message(chat_id=chat_id, text=title, reply_markup=kb, parse_mode=ParseMode.HTML); return

    if q and key.startswith("VIS_TOGGLE_"):
        flag = key.split("_")[-1].lower()
        cur = int(prefs.get(f"show_{flag}") or 0)
        update_prefs(conn, chat_id, **{f"show_{flag}": 0 if cur else 1})
        prefs = get_prefs(conn, chat_id)
        kb = visibility_menu_kb(prefs)
        await q.edit_message_text(_center_title("נראות דילים 👀"), reply_markup=kb, parse_mode=ParseMode.HTML); return

    if key in ("SAVED","שמורים"):
        flights = query_saved(conn, chat_id, limit=max_items)
        await _send_feed(update, context, flights, header="⭐ טיסות שמורות")
        return

    if q and key.startswith("SAVE::"):
        fkey = data.split("::",1)[1]
        conn.execute("INSERT OR IGNORE INTO saved_flights(chat_id, flight_key) VALUES(?,?)", (chat_id, fkey))
        conn.commit()
        await q.answer("⭐ נשמר")
        return

    if q and key.startswith("UNSAVE::"):
        fkey = data.split("::",1)[1]
        conn.execute("DELETE FROM saved_flights WHERE chat_id=? AND flight_key= ?", (chat_id, fkey))
        conn.commit()
        await q.answer("🗑 הוסר")
        return

    if q:
        try: await q.answer()
        except Exception: pass
    await context.bot.send_message(chat_id=chat_id, text="🏠 תפריט ראשי", reply_markup=main_menu_kb())
