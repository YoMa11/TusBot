# @@file_version: v2.4.7
from __future__ import annotations
import sqlite3
from typing import Dict, Any, List
from telegram import Bot
from telegram.constants import ParseMode
from telegram.error import BadRequest
from telegram_view import format_flight_card

EVENTS = ("new","removed","price_down","price_up","seats_down")

def _row(r): return {k:r[k] for k in r.keys()}

def _eligible_users(conn: sqlite3.Connection) -> List[int]:
    cur = conn.execute("SELECT chat_id FROM users WHERE subscribed=1")
    return [r[0] for r in cur.fetchall()]

def _delta(conn: sqlite3.Connection) -> Dict[str, List[Dict[str,Any]]]:
    out = {e: [] for e in EVENTS}
    cur = conn.execute("""
      SELECT * FROM flights
      WHERE scraped_at=(SELECT MAX(scraped_at) FROM flights) AND COALESCE(status,'active')='active'
    """)
    latest = [_row(r) for r in cur.fetchall()]
    keys_latest = {r.get("flight_key") for r in latest if r.get("flight_key")}

    prev_ts_row = conn.execute("""
      SELECT MAX(scraped_at) FROM flights
      WHERE scraped_at < (SELECT MAX(scraped_at) FROM flights)
    """).fetchone()
    prev_ts = prev_ts_row[0] if prev_ts_row else None
    prev = []
    if prev_ts:
        cur = conn.execute("SELECT * FROM flights WHERE scraped_at=?", (prev_ts,))
        prev = [_row(r) for r in cur.fetchall()]
    prev_map = {r.get("flight_key"): r for r in prev if r.get("flight_key")}

    prev_keys = set(prev_map.keys())
    removed_keys = prev_keys - keys_latest
    for k in removed_keys:
        rec = prev_map[k].copy(); rec["status"]="removed"; out["removed"].append(rec)

    for r in latest:
        k = r.get("flight_key")
        if k not in prev_map:
            out["new"].append(r)
        else:
            p = prev_map[k]
            if (r.get("price") or 0) < (p.get("price") or 0):
                out["price_down"].append(r)
            elif (r.get("price") or 0) > (p.get("price") or 0):
                out["price_up"].append(r)
            if r.get("seats") and p.get("seats") and r["seats"] < p["seats"]:
                out["seats_down"].append(r)
    return out

async def notify_changes(conn: sqlite3.Connection, bot: Bot):
    deltas = _delta(conn)
    users = _eligible_users(conn)
    if not users: return

    for chat_id in users:
        prefs = conn.execute("SELECT * FROM user_prefs WHERE chat_id=?", (chat_id,)).fetchone()
        show_new = int((prefs and prefs["show_new"]) or 1)
        show_removed = int((prefs and prefs["show_removed"]) or 0)
        max_items = int((prefs and prefs["max_items"]) or 30)

        bundles = []
        if show_new and deltas["new"]:
            bundles.append(("✨ טיסות חדשות", deltas["new"]))
        if deltas["price_down"]:
            bundles.append(("⬇️ ירידת מחיר", deltas["price_down"]))
        if deltas["seats_down"]:
            bundles.append(("⚠️ פחות מושבים", deltas["seats_down"]))
        if show_removed and deltas["removed"]:
            bundles.append(("🚫 טיסות שהוסרו", deltas["removed"]))

        for title, items in bundles:
            cards = [format_flight_card(f, show_removed=(title.startswith("🚫"))) for f in items[:max_items]]
            if not cards: continue
            text = f"<b>{title}</b>\n\n" + "\n\n".join(cards)
            try:
                await bot.send_message(chat_id=chat_id, text=text, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
            except BadRequest:
                pass
