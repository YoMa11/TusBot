from __future__ import annotations

from typing import Any, Dict
from telegram import Update
from telegram.ext import ContextTypes
from telegram.error import BadRequest

from db import (
    get_distinct_destinations,
    get_distinct_airlines,
    get_distinct_departure_dates,
    get_price_options,
)
from telegram_view import build_main_menu_from_db

async def safe_edit(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, reply_markup=None):
    q = update.callback_query
    if q and q.message:
        old_text = q.message.text or ""
        old_kb = q.message.reply_markup
        if old_text == text and str(old_kb) == str(reply_markup):
            return
        try:
            await q.edit_message_text(text, reply_markup=reply_markup)
            return
        except BadRequest as e:
            if "Message is not modified" in str(e):
                return
            raise
    else:
        await context.bot.send_message(chat_id=update.effective_chat.id, text=text, reply_markup=reply_markup)

def _load_menu_data(context: ContextTypes.DEFAULT_TYPE) -> Dict[str, Any]:
    conn = context.application.bot_data.get('conn')
    if conn is None:
        return {"destinations": [], "airlines": [], "dates": [], "prices": []}
    return {
        "destinations": get_distinct_destinations(conn),
        "airlines": get_distinct_airlines(conn),
        "dates": get_distinct_departure_dates(conn),
        "prices": get_price_options(conn),
    }

async def handle_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = _load_menu_data(context)
    kb = build_main_menu_from_db(data["destinations"], data["airlines"], data["dates"], data["prices"])
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="בחר/י ישירות מתוך האופציות החיות מה־DB:",
        reply_markup=kb
    )

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if q:
        await q.answer()

    data = _load_menu_data(context)
    kb = build_main_menu_from_db(data["destinations"], data["airlines"], data["dates"], data["prices"])

    cdata = (q.data if q else "") if q else ""
    if cdata in ("refresh", "menu:destinations", "menu:airlines", "menu:dates", "menu:prices", "help"):
        await safe_edit(update, context, "עודכן לפי ה־DB.", kb)
        return

    if cdata.startswith(("dest:", "air:", "date:", "price:")):
        await safe_edit(update, context, f"נבחר: {cdata}", kb)
        return

    await safe_edit(update, context, "בחר/י ישירות מתוך האופציות החיות מה־DB:", kb)
