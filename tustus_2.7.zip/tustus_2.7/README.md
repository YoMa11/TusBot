# tustus 2.7

גרסה מלאה עם:
- תפריט ראשי נבנה מתוך ה־DB (יעדים/חברות/תאריכים/מחירים).
- `safe_edit()` שמונעת שגיאת *Message is not modified*.
- JobQueue שמריץ `logic.run_monitor(conn, app)` כל `INTERVAL` שניות.
- שמירת `BOT_TOKEN` כפי שהוא (ללא שינוי שם משתנה).
- `botctl.sh` להפעלה/עצירה/סטטוס/דוקטור/לוגים.
- הרשאות 777 לכלל הקבצים בתיקייה.
