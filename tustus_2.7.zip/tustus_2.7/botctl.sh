#!/bin/sh
# tustus 2.7 control script (POSIX sh)
set -eu

DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
VENV="$DIR/.venv"
PYTHON="$VENV/bin/python"
PIP="$VENV/bin/pip"
APP="$DIR/app.py"
LOG="$DIR/bot.log"
PID="$DIR/bot.pid"
REQ="$DIR/requirements.txt"

export PYTHONPATH="$DIR"

usage() {
  echo "Usage: $0 {setup|start|stop|restart|status|doctor|logs}"
  exit 1
}

setup() {
  echo "[setup] creating venv at $VENV"
  if [ ! -d "$VENV" ]; then
    python3 -m venv "$VENV"
  fi
  echo "[setup] installing requirements ..."
  "$PIP" install -U pip wheel setuptools >/dev/null
  "$PIP" install -r "$REQ"
  echo "[setup] requirements installed."
}

start() {
  if [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; then
    echo "ALREADY RUNNING (PID $(cat "$PID"))"
    exit 0
  fi
  echo "Running from: $DIR"
  echo "Using PYTHON: $PYTHON"
  echo "ENV: PYTHONPATH=$PYTHONPATH"
  nohup "$PYTHON" "$APP" >>"$LOG" 2>&1 &
  echo $! > "$PID"
  echo "Started (PID $(cat "$PID")). Logs: $LOG"
}

stop() {
  if [ -f "$PID" ]; then
    if kill -0 "$(cat "$PID")" 2>/dev/null; then
      kill "$(cat "$PID")" || true
      rm -f "$PID"
      echo "Stopped."
    else
      rm -f "$PID"
      echo "Not running."
    fi
  else
    echo "Not running."
  fi
}

restart() {
  stop || true
  start
}

status() {
  if [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; then
    echo "RUNNING (PID $(cat "$PID"))"
  else
    echo "NOT RUNNING"
  fi
}

doctor() {
  "$PYTHON" - <<'PY'
import sys
print("[doctor] Python:", sys.version.split()[0], sys.version.split(" (")[0])
try:
    import telegram
    import telegram.ext
    print("[doctor] python-telegram-bot:", telegram.__version__)
except Exception as e:
    print("[doctor] python-telegram-bot: MISSING", e)
print("[doctor] OK")
PY
}

logs() {
  tail -n 200 -f "$LOG"
}

cmd="${1:-}"
case "$cmd" in
  setup) setup ;;
  start) start ;;
  stop) stop ;;
  restart) restart ;;
  status) status ;;
  doctor) doctor ;;
  logs) logs ;;
  *) usage ;;
esac
