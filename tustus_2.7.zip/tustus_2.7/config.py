from __future__ import annotations

# ======================
#   tustus CONFIG 2.7
# ======================

# אל תשנה כאן שמות משתנים ללא אישור הלקוח.
# הלקוח ביקש לשמור BOT_TOKEN כפי שהוא.
BOT_TOKEN: str = "PUT-YOUR-TELEGRAM-BOT-TOKEN-HERE"

# מסלול ה-DB המקומי (נשמר לצורך היסטוריה/סטטיסטיקות)
DB_PATH: str = "./flights.db"

# מרווח ניטור/רענון ברירת מחדל (שניות)
INTERVAL: int = 60

# גרסת קוד לצורך לוגים
VERSION: str = "2.7"
