from __future__ import annotations

import logging, sqlite3
from telegram.ext import (
    Application,
    CommandHandler, CallbackQueryHandler, ContextTypes
)

from config import BOT_TOKEN, DB_PATH, INTERVAL, VERSION
from utils import setup_logging
import db as dbmod
import logic as lg
from handlers import handle_start, handle_callback

def _open_db(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

async def _tick(context: ContextTypes.DEFAULT_TYPE) -> None:
    app = context.application
    conn = app.bot_data.get('conn')
    if conn is None:
        logging.error("run_monitor tick failed: no DB connection in bot_data")
        return
    await lg.run_monitor(conn, app)

def main() -> None:
    setup_logging("./bot.log")
    logging.info("🚀 הפעלה (גרסה V%s) | interval=%ss | DB=%s", VERSION, INTERVAL, DB_PATH)

    app = Application.builder().token(BOT_TOKEN).build()
    conn = _open_db(DB_PATH)
    dbmod.ensure_schema(conn)
    app.bot_data['conn'] = conn

    # Handlers
    app.add_handler(CommandHandler("start", handle_start))
    app.add_handler(CallbackQueryHandler(handle_callback))

    # JobQueue repeating
    app.job_queue.run_repeating(_tick, interval=INTERVAL, name="monitor")
    logging.info("🗓️  JobQueue repeating task scheduled (interval=%ss)", INTERVAL)

    app.run_polling(close_loop=False)
    logging.info("Application.stop() complete")

if __name__ == "__main__":
    main()
