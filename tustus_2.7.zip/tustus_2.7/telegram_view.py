from __future__ import annotations

from telegram import InlineKeyboardMarkup, InlineKeyboardButton

def _chunk(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i+n]

def build_main_menu_from_db(destinations, airlines, dates, price_options):
    rows = []
    rows.append([InlineKeyboardButton("✈️ יעדים", callback_data="menu:destinations")])
    rows += [[InlineKeyboardButton(d, callback_data=f"dest:{d}")] for d in destinations[:20]]
    rows.append([InlineKeyboardButton("🏷️ חברות תעופה", callback_data="menu:airlines")])
    rows += [[InlineKeyboardButton(a, callback_data=f"air:{a}")] for a in airlines[:20]]
    rows.append([InlineKeyboardButton("🗓️ תאריכים", callback_data="menu:dates")])
    rows += [[InlineKeyboardButton(dt, callback_data=f"date:{dt}")] for dt in dates[:20]]
    rows.append([InlineKeyboardButton("💰 מחירים", callback_data="menu:prices")])
    rows += [[InlineKeyboardButton(lbl, callback_data=f"price:{lbl}")] for (lbl, _p) in price_options[:20]]

    rows.append([
        InlineKeyboardButton("🔄 רענון", callback_data="refresh"),
        InlineKeyboardButton("ℹ️ עזרה", callback_data="help"),
    ])

    out = []
    for r in rows:
        if len(r) == 1:
            out.append(r)
        else:
            out += list(_chunk(r, 2))
    return InlineKeyboardMarkup(out)
