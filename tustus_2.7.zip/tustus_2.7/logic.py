from __future__ import annotations
import logging, sqlite3
from typing import Any

async def run_monitor(conn: sqlite3.Connection, app: Any) -> None:
    """הרצת ניטור חוזרת. כאן קוראים לפונקציות לוגיקה נדרשות."""
    try:
        await monitor_job(conn, app)
    except Exception:
        logging.exception("monitor_job raised")

async def monitor_job(conn: sqlite3.Connection, app: Any) -> None:
    """פעולת ניטור בסיסית: כרגע רק מוודאת שה-DB נגיש ומדווחת על מספר רשומות."""
    try:
        cur = conn.execute("SELECT COUNT(*) FROM flights")
        (n,) = cur.fetchone()
        logging.info("monitor_job: flights rows=%s", n)
    except Exception:
        logging.exception("monitor_job: DB error")
