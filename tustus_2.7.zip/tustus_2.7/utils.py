from __future__ import annotations

import logging

def setup_logging(log_path: str = "./bot.log") -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_path, encoding="utf-8"),
            logging.StreamHandler()
        ],
    )
    logging.info("📝 logging to %s", log_path)

def log_exception(prefix: str, exc: BaseException) -> None:
    import traceback
    logging.error("%s: %s", prefix, exc)
    logging.error("Traceback:\n%s", "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
