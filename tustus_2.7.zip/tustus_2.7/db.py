from __future__ import annotations
from typing import List, Tuple
import sqlite3, logging, os

def ensure_schema(conn: sqlite3.Connection, schema_path: str = "./schema.sql") -> None:
    if not os.path.exists(schema_path):
        logging.warning("schema.sql not found at %s", schema_path)
        return
    with open(schema_path, "r", encoding="utf-8") as f:
        sql = f.read()
    conn.executescript(sql)
    conn.commit()
    logging.info("✅ DB schema ensured")

def get_distinct_destinations(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute("""
        SELECT DISTINCT destination
        FROM flights
        WHERE destination IS NOT NULL AND TRIM(destination) <> ''
        ORDER BY destination COLLATE NOCASE
    """)
    return [r[0] for r in cur.fetchall()]

def get_distinct_airlines(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute("""
        SELECT DISTINCT airline
        FROM flights
        WHERE airline IS NOT NULL AND TRIM(airline) <> ''
        ORDER BY airline COLLATE NOCASE
    """)
    return [r[0] for r in cur.fetchall()]

def get_distinct_departure_dates(conn: sqlite3.Connection) -> List[str]:
    # מחזיר YYYY-MM-DD מתוך departure_time
    cur = conn.execute("""
        SELECT DISTINCT substr(departure_time, 1, 10) AS d
        FROM flights
        WHERE departure_time IS NOT NULL AND length(departure_time) >= 10
        ORDER BY d
    """)
    return [r[0] for r in cur.fetchall()]

def get_price_options(conn: sqlite3.Connection) -> List[Tuple[str, float]]:
    cur = conn.execute("""
        SELECT DISTINCT COALESCE(currency, '') AS ccy, price
        FROM flights
        WHERE price IS NOT NULL
        ORDER BY ccy, price
    """)
    out = []
    for ccy, price in cur.fetchall():
        if price is None:
            continue
        label = f"{price:g} {ccy}".strip()
        out.append((label, float(price)))
    return out
