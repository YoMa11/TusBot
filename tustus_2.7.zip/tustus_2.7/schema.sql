-- flights schema (minimal, safe defaults)
CREATE TABLE IF NOT EXISTS flights (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    destination TEXT,
    airline TEXT,
    departure_time TEXT, -- ISO-like string
    arrival_time   TEXT,
    price REAL,
    currency TEXT,
    removed INTEGER DEFAULT 0, -- 0 active, 1 removed
    seats INTEGER,
    url TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_flights_destination ON flights(destination);
CREATE INDEX IF NOT EXISTS idx_flights_airline ON flights(airline);
CREATE INDEX IF NOT EXISTS idx_flights_departure ON flights(departure_time);
CREATE INDEX IF NOT EXISTS idx_flights_removed ON flights(removed);
