from __future__ import annotations
# UI helpers could live here; keeping file for parity with user's tree.
