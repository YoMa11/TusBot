# ⚠️ ערוך רק אם תרצה. הקוד לא משנה קובץ זה לעולם.
# שמור שמות משתנים כפי שהם.
BOT_TOKEN = "PUT-YOUR-TELEGRAM-BOT-TOKEN-HERE"
DB_PATH = "./flights.db"
INTERVAL = 60  # שניות
