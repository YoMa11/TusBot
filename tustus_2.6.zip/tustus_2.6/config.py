# -*- coding: utf-8 -*-
from __future__ import annotations

# גרסה
VERSION = "2.6"

# מרווח ניטור בשניות (דרישה: 60)
INTERVAL = 60

# נתיב בסיס הנתונים
DB_PATH = "flights.db"

# טוקן של הטלגרם - נשאר בקובץ הקונפיג (לבקשתך)
# ניתן להחליף כאן או לדרוס דרך משתנה סביבה TELEGRAM_BOT_TOKEN_RUNTIME
TELEGRAM_BOT_TOKEN = "PUT_TOKEN_HERE"
