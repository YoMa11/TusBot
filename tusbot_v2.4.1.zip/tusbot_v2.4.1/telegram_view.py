from __future__ import annotations

import html
from typing import List, Dict, Any, Tuple

from telegram import InlineKeyboardMarkup, InlineKeyboardButton

# ========= helpers =========

MAX_TG = 4096

def _is_eilat(dest: str | None) -> bool:
    if not dest:
        return False
    d = dest.strip().lower()
    return "eilat" in d or "אילת" in d

def format_price(price: int | float | None, destination: str | None = None) -> str:
    """
    כלל כפי שביקשת:
    - ברירת מחדל USD ($)
    - אם היעד כולל 'אילת' → ₪
    """
    if price is None:
        return "—"
    if _is_eilat(destination):
        return f"{int(price):,}₪".replace(",", ",")
    return f"${int(price):,}".replace(",", ",")

def _fmt_time(hhmm: str | None) -> str:
    return hhmm or "—"

def _fmt_date(iso: str | None) -> str:
    # iso YYYY-MM-DD → DD/MM
    if not iso or len(iso) < 10:
        return "—"
    return f"{iso[8:10]}/{iso[5:7]}"

# ========= cards & chunking =========

def format_flight_card(f: Dict[str, Any], show_active_time: bool = True) -> str:
    """
    יוצר כרטיס HTML לטלגרם.
    f מ־flights: name, destination, link, price, go_date, go_depart, go_arrive,
                 back_date, back_depart, back_arrive, seats, first_seen, scraped_at, flight_key
    """
    name = html.escape(f.get("name") or f.get("destination") or "טיסה")
    dest = html.escape(f.get("destination") or "")
    link = f.get("link") or ""
    price_s = format_price(f.get("price"), f.get("destination"))

    gd = _fmt_date(f.get("go_date"))
    bd = _fmt_date(f.get("back_date"))
    gdep = _fmt_time(f.get("go_depart"))
    garr = _fmt_time(f.get("go_arrive"))
    bdep = _fmt_time(f.get("back_depart"))
    barr = _fmt_time(f.get("back_arrive"))
    seats = f.get("seats")
    seats_s = "—" if seats in (None, "", 0) else str(seats)

    when = f.get("scraped_at") or f.get("first_seen") or ""
    when_s = f" <i>⏱ {html.escape(when)}</i>" if (when and show_active_time) else ""

    # שים לב לשימוש ב-<b> / <code> / <a> עבור HTML Mode
    parts = [
        f"<b>{name}</b>",
        f"<i>{dest}</i>" if dest else "",
        f"<b>{price_s}</b>",
        "",
        f"✈️ יציאה: {gd}  {gdep} → {garr}",
        f"↩️ חזרה: {bd}  {bdep} → {barr}",
        f"🪑 מושבים: {seats_s}{when_s}",
    ]
    if link:
        parts.append(f'<a href="{html.escape(link)}">להזמנה</a>')
    return "\n".join([p for p in parts if p is not None and p != ""])

def chunk_messages(cards: List[str], header: str = "") -> List[str]:
    """
    מחלק רשימת כרטיסים למסרונים עד 4096 תווים.
    """
    chunks: List[str] = []
    cur = header.strip()
    if cur:
        cur = cur + "\n\n"
    for c in cards:
        c2 = c if c.endswith("\n") else c + "\n"
        if len(cur) + len(c2) > MAX_TG:
            chunks.append(cur.rstrip())
            cur = ""
        cur += (c2 + "\n")
    if cur.strip():
        chunks.append(cur.rstrip())
    return chunks

def paginate_cards(
    flights: List[Dict[str, Any]],
    prefs: Dict[str, Any] | None = None,
    page: int = 1,
    page_size: int = 10,
    show_active_time: bool = True,
) -> Tuple[List[str], InlineKeyboardMarkup, int, int]:
    """
    מחזיר:
      - cards: רשימת כרטיסים מעוצבים (לטקסט)
      - nav_kb: מקלדת ניווט (כפתור בית; ניתן להרחיב לעמודים)
      - page: העמוד הנוכחי
      - total_pages: סה״כ עמודים
    כרגע מספק ניווט בסיסי (בית). אם תרצה פג׳ינג מלא נוסיף callbacks ייעודיים.
    """
    total = max(1, (len(flights) + page_size - 1) // page_size)
    page = max(1, min(page, total))
    start = (page - 1) * page_size
    end = start + page_size
    sub = flights[start:end]
    cards = [format_flight_card(f, show_active_time=show_active_time) for f in sub]
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("🏠 בית", callback_data="HOME")]])
    return cards, kb, page, total

# ========= keyboards =========

def main_menu_kb() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton("👀 כל הדילים", callback_data="SHOW_ALL"),
            InlineKeyboardButton("🎯 לפי העדפות", callback_data="BY_PREFS"),
        ],
        [
            InlineKeyboardButton("💸 מחיר", callback_data="PRICE"),
            InlineKeyboardButton("🪑 מושבים", callback_data="SEATS"),
        ],
        [
            InlineKeyboardButton("🗓 תאריכים", callback_data="DATES"),
            InlineKeyboardButton("🧾 אורך טיול", callback_data="TRIP"),
        ],
        [
            InlineKeyboardButton("🎯 יעדים", callback_data="DESTS"),
            InlineKeyboardButton("👀 נראות", callback_data="VIS"),
        ],
        [
            InlineKeyboardButton("⭐ שמורים", callback_data="SAVED"),
            InlineKeyboardButton("📊 סיכום לפי יעד", callback_data="SUMMARY"),
        ],
        [
            InlineKeyboardButton("🔕 מצב שקט", callback_data="QUIET_TOGGLE"),
            InlineKeyboardButton("♻️ איפוס", callback_data="RESET"),
        ],
    ]
    return InlineKeyboardMarkup(rows)

def feed_nav_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("🏠 בית", callback_data="HOME")]])

def destinations_page(selected_csv: str, page: int, page_size: int, all_dests: List[str]) -> InlineKeyboardMarkup:
    selected = {d.strip() for d in (selected_csv or "").split(",") if d.strip()}
    total = max(1, (len(all_dests) + page_size - 1) // page_size)
    page = max(1, min(page, total))
    start = (page - 1) * page_size
    end = start + page_size
    sub = all_dests[start:end]

    rows: List[List[InlineKeyboardButton]] = []
    for d in sub:
        mark = "✅" if d in selected else "⬜️"
        cb = f"DEST_TOGGLE::{d}|PAGE_{page}"
        rows.append([InlineKeyboardButton(f"{mark} {d}", callback_data=cb)])

    nav: List[InlineKeyboardButton] = []
    if page > 1:
        nav.append(InlineKeyboardButton("⟵ הקודם", callback_data=f"DESTS_PAGE_{page-1}"))
    if page < total:
        nav.append(InlineKeyboardButton("הבא ⟶", callback_data=f"DESTS_PAGE_{page+1}"))
    if nav:
        rows.append(nav)

    rows.append([
        InlineKeyboardButton("✅ שמור וחזור", callback_data="DEST_SAVE"),
        InlineKeyboardButton("🏠 בית", callback_data="HOME"),
    ])
    return InlineKeyboardMarkup(rows)

def price_menu_kb(prefs: Dict[str, Any] | None = None) -> InlineKeyboardMarkup:
    # סולמות טיפוסיים (אפשר לשנות)
    steps = [100, 150, 200, 250, 300, 400, 500]
    row1 = [InlineKeyboardButton(f"${s}", callback_data=f"PRICE_SET_{s}") for s in steps[:4]]
    row2 = [InlineKeyboardButton(f"${s}", callback_data=f"PRICE_SET_{s}") for s in steps[4:]]
    row3 = [
        InlineKeyboardButton("נקה", callback_data="PRICE_CLEAR"),
        InlineKeyboardButton("🏠 בית", callback_data="HOME"),
    ]
    return InlineKeyboardMarkup([row1, row2, row3])

def seats_menu_kb(prefs: Dict[str, Any] | None = None) -> InlineKeyboardMarkup:
    # מצב סוללה פשוט (1..5) + נקה + בית
    row1 = [InlineKeyboardButton(str(n), callback_data=f"SEATS_SET_{n}") for n in range(1, 6)]
    row2 = [
        InlineKeyboardButton("נקה", callback_data="SEATS_CLEAR"),
        InlineKeyboardButton("🏠 בית", callback_data="HOME"),
    ]
    return InlineKeyboardMarkup([row1, row2])

def dates_menu_kb() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton("שבוע קדימה", callback_data="DATES_WEEK"),
            InlineKeyboardButton("חודש נוכחי", callback_data="DATES_MONTH"),
        ],
        [
            InlineKeyboardButton("טווח ידני", callback_data="DATES_MANUAL"),
            InlineKeyboardButton("נקה", callback_data="DATES_CLEAR"),
        ],
        [InlineKeyboardButton("🏠 בית", callback_data="HOME")],
    ]
    return InlineKeyboardMarkup(rows)

def trip_len_menu_kb() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton("3–4 לילות", callback_data="TRIP_SET_3-4"),
            InlineKeyboardButton("5–7 לילות", callback_data="TRIP_SET_5-7"),
        ],
        [
            InlineKeyboardButton("8–10 לילות", callback_data="TRIP_SET_8-10"),
            InlineKeyboardButton("11–14 לילות", callback_data="TRIP_SET_11-14"),
        ],
        [
            InlineKeyboardButton("נקה", callback_data="TRIP_CLEAR"),
            InlineKeyboardButton("🏠 בית", callback_data="HOME"),
        ],
    ]
    return InlineKeyboardMarkup(rows)

def visibility_menu_kb(prefs: Dict[str, Any]) -> InlineKeyboardMarkup:
    """
    מציג טוגלים ל־show_new / show_active / show_removed
    """
    def flag_txt(flag: str, label: str) -> str:
        v = int(prefs.get(flag) or 0)
        return f"{'✅' if v else '⬜️'} {label}"

    rows = [
        [
            InlineKeyboardButton(flag_txt("show_new", "חדשים"), callback_data="VIS_TOGGLE_NEW"),
            InlineKeyboardButton(flag_txt("show_active", "פעילים"), callback_data="VIS_TOGGLE_ACTIVE"),
        ],
        [
            InlineKeyboardButton(flag_txt("show_removed", "הוסרו"), callback_data="VIS_TOGGLE_REMOVED"),
            InlineKeyboardButton("🏠 בית", callback_data="HOME"),
        ]
    ]
    return InlineKeyboardMarkup(rows)


def elide(label: str, max_len: int = 16) -> str:
    return label if len(label) <= max_len else (label[: max_len - 1] + "…")


def _fmt_hm(hhmm: str | None) -> str:
    return hhmm if (hhmm and len(hhmm) >= 4) else "—"

def format_price(destination: str | None, price: int | float | str | None) -> str:
    if price in (None, "", 0, "0"): return "—"
    try:
        p = int(float(price))
    except Exception:
        return "—"
    sym = "₪" if (destination or "").find("אילת") >= 0 else "$"
    return f"{sym}{p:,}".replace(",", ",")

def format_flight_card(f: dict) -> str:
    dest = (f.get("destination") or f.get("name") or "").strip() or "יעד"
    go_d, back_d = _fmt_date(f.get("go_date")), _fmt_date(f.get("back_date"))
    go_dep, go_arr = _fmt_hm(f.get("go_depart")), _fmt_hm(f.get("go_arrive"))
    bk_dep, bk_arr = _fmt_hm(f.get("back_depart")), _fmt_hm(f.get("back_arrive"))
    seats = f.get("seats")
    seats_txt = "—" if seats in (None, "", 0, "0") else str(seats)
    price_txt = format_price(dest, f.get("price"))
    link = (f.get("link") or "").strip()
    fkey = f.get("flight_key") or f.get("id") or ""

    parts = []
    parts.append(f"<b>🌍 {dest}</b>  •  <b>{go_d}–{back_d}</b>")
    parts.append(f"<b>⏰ הלוך:</b> {go_dep} → {go_arr}  |  <b>חזור:</b> {bk_dep} → {bk_arr}")
    parts.append(f"<b>🪑 מושבים:</b> {seats_txt}  |  <b>💸 מחיר:</b> {price_txt}")
    if link:
        parts.append(f'<a href="{link}">🚀 להזמנה</a>  •  <code>{fkey}</code>')
    else:
        parts.append(f'<code>{fkey}</code>')
    return "\n".join(parts)

def main_menu_kb():
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    rows = [
        [InlineKeyboardButton("🔎 תראה עכשיו", callback_data="SHOW_ALL"),
         InlineKeyboardButton("🎯 לפי ההעדפות", callback_data="BY_PREFS")],
        [InlineKeyboardButton("🎯 יעדים", callback_data="DESTS"),
         InlineKeyboardButton("💸 מחיר", callback_data="PRICE"),
         InlineKeyboardButton("🪑 מושבים", callback_data="SEATS")],
        [InlineKeyboardButton("🗓 תאריכים", callback_data="DATES"),
         InlineKeyboardButton("🧾 אורך טיול", callback_data="TRIP"),
         InlineKeyboardButton("👀 נראות", callback_data="VIS")],
        [InlineKeyboardButton("⭐ שמורים", callback_data="SAVED"),
         InlineKeyboardButton("📊 סיכום לפי יעד", callback_data="SUMMARY")],
        [InlineKeyboardButton("🔕 מצב שקט", callback_data="QUIET_TOGGLE"),
         InlineKeyboardButton("♻️ איפוס", callback_data="RESET"),
         InlineKeyboardButton("🏠 בית", callback_data="HOME")],
    ]
    return InlineKeyboardMarkup(rows)

def destinations_page(selected_csv: str, page: int, page_size: int, dests_all: list):
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    selected = set([d.strip() for d in (selected_csv or "").split(",") if d.strip()])
    total = len(dests_all)
    page = max(1, page)
    start = (page - 1) * page_size
    end = min(start + page_size, total)
    chunk = dests_all[start:end]

    rows = []
    for i in range(0, len(chunk), 2):
        row = []
        for j in range(2):
            if i + j >= len(chunk): break
            name = chunk[i + j]
            checked = "✅" if name in selected else "⬜️"
            label = f"{checked} {elide(name)}"
            row.append(InlineKeyboardButton(label, callback_data=f"DEST_TOGGLE::{name}|PAGE_{page}"))
        rows.append(row)

    nav = []
    if start > 0:
        nav.append(InlineKeyboardButton("◀️ קודם", callback_data=f"DESTS_PAGE_{page-1}"))
    nav.append(InlineKeyboardButton("✅ שמור וחזור", callback_data="DEST_SAVE"))
    if end < total:
        nav.append(InlineKeyboardButton("▶️ הבא", callback_data=f"DESTS_PAGE_{page+1}"))
    rows.append(nav)
    return InlineKeyboardMarkup(rows)

def feed_nav_kb():
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 בית", callback_data="HOME"),
         InlineKeyboardButton("🎯 לפי ההעדפות", callback_data="BY_PREFS"),
         InlineKeyboardButton("🔎 תראה עכשיו", callback_data="SHOW_ALL")],
        [InlineKeyboardButton("⭐ שמורים", callback_data="SAVED")]
    ])

def chunk_messages(cards: list, header: str = "") -> list:
    MAX = 3500
    out, cur = [], (header + "\n\n") if header else ""
    for c in cards:
        add = (c if not cur else ("\n\n" + c))
        if len(cur) + len(add) > MAX:
            out.append(cur.rstrip())
            cur = c
        else:
            cur += add
    if cur.strip():
        out.append(cur.rstrip())
    return out
